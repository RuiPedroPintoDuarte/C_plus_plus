//		Crie a classe Pessoa com os atributos (nome, datan, morada) dos tipos (string, Data, string) 
//		respetivamente utilizando fun��es inline para os m�todos de acesso.
//		(Esta classe al�m do nome e da morada guarda a data de nascimento da pessoa.)
//
//	a)x	Implemente os construtores por defeito e com par�metros da classe Pessoa.
//	b)	Crie 2 objetos do tipo Pessoa com os seguintes atributos :
//		i.Jonas Culatra; 20 / 9 / 1987; Rua da direita n 2.
//		ii.Joni Rato; 4 / 2 / 1990; Rua da esquerda n 3.
//	c)x	Implemente o m�todo Show() e mostre no ecr� os dados das pessoas criadas na al�nea anterior.
//	d)	Altere a morada do �Joni Rato�. A nova morada deve ser lida atrav�s do teclado.
//	e)	Altere a data de nascimento do �Joni Rato�. A nova data de nascimento deve ser lida atrav�s 
//		do teclado.
//	f)x	Implemente o m�todo ReadK() que permita ler todos os dados de uma pessoa atrav�s do teclado.
//		Crie um 3� objeto do tipo Pessoa e use este m�todo para ler os seus dados.
//	g)x	Implemente a sobrecarga dos operadores  � << � e � >> � na classe Pessoa. Use o construtor 
//		por defeito para definir uma nova Pessoa e use os operadores  � << � e � >> �  para ler e 
//		mostrar os seus dados.
//	h)x	Implemente a sobrecarga dos operadores � == �, � != �, que faz a compara��o do nome e data 
//		de nascimento; No programa verifique se 2  pessoas s�o iguais
//	i)x	Implemente o m�todo MaisNovo() para verificar entre duas pessoas qual � a mais nova.Deve ser
//		apresentado no ecr� a informa��o completa da Pessoa mais nova.
//	j)x	Implemente o m�todo SaveFile() para guardar todos os dados de uma pessoa em ficheiro. Use 
//		este m�todo para guardar os dados de todas as pessoas em ficheiro. O nome do ficheiro deve 
//		ser lido atrav�s do teclado.
//	k)x	Implemente o m�todo ReadFile()que permita ler todos os dados de uma pessoa a partir de um 
//		ficheiro.
//	l)	Implemente o c�digo necess�rio para ler os dados do ficheiro, criado na al�nea anterior, para um vetor de objetos do tipo Pessoa.
//	m)	Apresente a informa��o completa das pessoas cuja data de nascimento seja anterior a 1990.
//
// x - m�todo implementado (total ou parcialmente) na classe Pessoa


#include <iostream>
#include <fstream>
#include <string>

#include "Data.h"
#include "Pessoa.h"

using namespace std;

void readTest(void) {
	string str = "pessoas.txt";
	char aux;

	cout << endl;
	Pessoa P[9];													//	l)...
	int size = 0, i = 0;
	ifstream ifile;

	ifile.open(str);			// mesmo ficheiro da al�nea anterior
	if (ifile) {
		while ((aux = ifile.peek()) != EOF) {
			P[size].ReadFile(ifile);
			ifile.get();
			size++;
		}
		ifile.close();
		cout << endl << "Ficheiro " << str << " lido  para memoria (vetor), com sucesso. " << endl;
	}
	else {
		cout << endl << "ERRO: nao e possivel abrir o ficheiro " << str << endl << endl;
	}
	//	...l)

	cout << endl;
	cout << "Pessoas: " << endl;				//	m)
	for (i = 0; i < size; i++) {
		cout << endl << endl;  P[i].Show();
	}
	//	...m)
	cout << endl << endl;
	system("pause");
}

int main(void) {

	readTest();
	return 0;

	string str;
	char aux[100];

	cout << endl << endl;
	Pessoa a("Jonas Culatra", "Rua da direita n2", Data(20, 9, 1987)),	//	b) i)
		b("Joni Rato", "Rua da esquerda n3", 4, 2, 1990);				//	b) ii)

	cout << endl;
	cout << endl; a.Show();											//	c)
	cout << endl; b.Show();											//	c)

	cout << endl;
	cout << a.GetNome() << " - Alteracao de Morada: ";				//	d)
	cin.getline(aux, sizeof aux, '\n');								//	d)
	b.SetMorada(aux);												//	d)

	cout << endl;
	cout << a.GetNome() << " - Alteracao da data de Nascimento: " << endl;
	Data _data;														//	e)
	cin >> _data;													//	e)
	a.SetData(_data);												//	e)

	cout << endl;
	cout << "Insira a nova pesssoa (ReadK): " << endl;
	Pessoa c;														//	f)
	c.ReadK();														//	f)

	cout << endl;
	cout << "Insira a nova pesssoa (<< >>): " << endl;
	Pessoa d;														//	g)
	cin >> d;														//	g)
	cout << d;														//	g)

	cout << endl;
	if (a == b) {													//	h)
		cout << "As pessoas " << a.GetNome() << " e " << b.GetNome() << " sao iguais.";
	}
	else {
		cout << "As pessoas " << a.GetNome() << " e " << b.GetNome() << " sao diferentes.";
	}

	cout << endl;
	if (a.MaisNovo(b)) {											//	i)
		cout << " O mais novo e: " << a << endl;
	}
	else {
		cout << " O mais novo e: " << b << endl;
	}


	cout << endl;
	cout << "Nome do ficheiro para guardar as pessoas: ";			//	j)...
	cin >> str; //	str="pessoas.txt";

	ofstream ofile;
	ofile.open(str);
	if (ofile) {
		a.SaveFile(ofile);	ofile << endl;
		b.SaveFile(ofile);	ofile << endl;
		c.SaveFile(ofile);	ofile << endl;
		d.SaveFile(ofile);	ofile << endl;
		ofile.close();
		cout << "Ficheiro " << str << " criado com sucesso!" << endl;
	}
	else {
		cout << "ERRO: nao e possivel abrir o ficheiro " << str << endl;
	}
	//	...j)

	cout << endl;
	Pessoa P[9];													//	l)...
	int size = 0, i = 0;
	ifstream ifile;

	ifile.open(str);			// mesmo ficheiro da al�nea anterior
	if (ifile) {
		while (ifile.peek() != EOF) {
			P[size].ReadFile(ifile);
			ifile.get();
			size++;
		}
		ifile.close();
		cout << endl << "Ficheiro " << str << " lido  para memoria (vetor), com sucesso. " << endl;
	}
	else {
		cout << endl << "ERRO: nao e possivel abrir o ficheiro " << str << endl << endl;
	}
	//	...l)

	cout << endl;
	cout << "Pessoas nascidas antes de 1990: " << endl;				//	m)
	for (i = 0; i < size; i++) {
		if (P[i].GetData().GetAno() < 1990) {
			cout << endl << endl;  P[i].Show();
		}
	}
	//	...m)
	cout << endl << endl;
	system("pause");
	return 0;
}
