#include <iostream>

#include "Titular.h"
#include "Standart.h"
#include "Select.h"
#include "Platina.h"

using namespace std;
int main(void) {

	

	cout << endl;
	system("pause");
	return 0;
}