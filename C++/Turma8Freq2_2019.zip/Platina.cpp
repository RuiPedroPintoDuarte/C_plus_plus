#include "Platina.h"

Platina::Platina(){
}

Platina::~Platina(){
}
