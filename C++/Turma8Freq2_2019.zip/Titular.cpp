#include "Titular.h"

Titular::Titular(){
}

Titular::~Titular(){
}
