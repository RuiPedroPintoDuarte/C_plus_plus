#include "Standart.h"

Standart::Standart()
{
}

Standart::~Standart()
{
}
